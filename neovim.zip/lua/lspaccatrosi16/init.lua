-- Settings first
require("lspaccatrosi16.set")

-- Packer setup next
require("lspaccatrosi16.packer")

-- Setup next
require("lspaccatrosi16/config")

-- Remaps at the end
require("lspaccatrosi16/remaps")
