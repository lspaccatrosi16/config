vim.cmd("colorscheme nordfox")
