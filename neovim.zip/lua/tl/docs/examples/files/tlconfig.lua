return {
   build_dir = "build",
   source_dir = "src",
}